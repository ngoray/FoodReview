function showChinese() {

    category="chinese";
    displaySelected(category);
}

function showIndian() {

    category="indian";
    displaySelected(category);
}

function showMalay() {

    category="malay";
    displaySelected(category);
}

function showThai() {

    category="thai";
    displaySelected(category);
}

function showWestern() {

    category="western";
    displaySelected(category);
}

function showJapanese() {

    category="japanese";
    displaySelected(category);
}

function showItalian() {

    category="italian";
    displaySelected(category);
}

function showKorean() {

    category="korean";
    displaySelected(category);
}